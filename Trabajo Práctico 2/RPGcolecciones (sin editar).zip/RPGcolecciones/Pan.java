public class Pan extends Elemento {

    public Pan() {
        setNombre("Pan");
        setPeso(2);
        setTipo(TipoElemento.ALIMENTO);
    }
    
}
