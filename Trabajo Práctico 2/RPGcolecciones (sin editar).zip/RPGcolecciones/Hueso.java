public class Hueso extends Elemento {

    public Hueso() {
        setNombre("Hueso");
        setPeso(1);
        setTipo(TipoElemento.INGREDIENTE);
    }
    
}