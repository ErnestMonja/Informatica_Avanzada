public class Vino extends Elemento {

    public Vino () {
        setNombre("Vino");
        setPeso(20);
        setTipo(TipoElemento.LIQUIDO);
    }

}
