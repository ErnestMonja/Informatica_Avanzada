public class Flecha extends Elemento {

    public Flecha() {
        setNombre("Flecha");
        setPeso(3);
        setTipo(TipoElemento.MUNICION);
    }
    
}
