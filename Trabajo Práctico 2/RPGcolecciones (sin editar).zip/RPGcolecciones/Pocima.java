public class Pocima extends Elemento {

    public Pocima(String nombre, Integer peso) {
        setNombre("Pocima de " + nombre);
        setPeso(peso);
        setTipo(TipoElemento.LIQUIDO);
    }
    
}
