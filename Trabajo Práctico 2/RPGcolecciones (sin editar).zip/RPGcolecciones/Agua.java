public class Agua extends Elemento {

    public Agua () {
        setNombre("Agua");
        setPeso(25);
        setTipo(TipoElemento.LIQUIDO);
    }
    
}
