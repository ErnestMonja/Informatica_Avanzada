public class Pluma extends Elemento {

    public Pluma() {
        setNombre("Pluma");
        setPeso(1);
        setTipo(TipoElemento.INGREDIENTE);
    }
    
}