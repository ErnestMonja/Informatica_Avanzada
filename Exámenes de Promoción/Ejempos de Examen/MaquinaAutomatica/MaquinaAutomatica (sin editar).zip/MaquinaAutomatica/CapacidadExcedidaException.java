/*
 * Excepcion para falla en capacidad del recipiente
 */
public class CapacidadExcedidaException extends Exception {

}
