/*
 * Estados de la maquina 
 */
public enum Estado {
    OPERANDO, LISTO, APAGADO, MANTENIMIENTO
}
