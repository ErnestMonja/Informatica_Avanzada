/*
 * Excepcion para falla en prerarar receta
 */
public class ProductoException extends Exception {

	public ProductoException(String s) {
		super (s);
	}

}
