/*
 * Ingredientes para las recetas
 */
public enum Ingrediente {
    CAFE, LECHE, AZUCAR, CACAO, AGUA
}
