 

public class CalleIncorrectaException extends Exception {
}
