import java.util.ArrayList;
import java.util.List;

/**
 * Modelo simplificado de una calle de 2 vias
 */
public class Calle {

    private String nombre;
    private Integer longitud; // Longitud [mts]
    private List<InterseccionInterface> intersecciones;

    /**
     * Inicializacion
     * @param nombre nombre de la calle
     * @param longitud longitud máxima disponible
     */
    public Calle(String nombre, Integer longitud){
        //Completar
    }


    /**
     * Agrega una nueva interseccion a esta calle
     * no puede contener intersecciones repetidas
     * @param inte Interseccion a ser agregada 
     */
    public void agregar_interseccion(InterseccionInterface inte){
        //Completar 
    }

    /**
     *
     * @return longitud de la calle
     */
    public Integer get_longitud(){
        return null;
    }

    /**
     *
     * @return lista con todas las intersecciones por las que es afectada esta calle
     */
    public List<InterseccionInterface> get_intersecciones(){
        //Completar
        return null;
    }

    /**
     * @return devuelve el nombre de la calle
     */
    @Override
    public String toString() {
        //Completar
        return "";
    }
}
