    public enum ESTADOS {
        VERDE,
        ROJO
    }
