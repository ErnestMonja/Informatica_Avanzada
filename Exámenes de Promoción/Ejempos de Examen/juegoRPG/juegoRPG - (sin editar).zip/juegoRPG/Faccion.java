 

public enum Faccion{
    EQUIPO_ROJO,
    EQUIPO_AZUL
}