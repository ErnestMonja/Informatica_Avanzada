 
/**
 * Interfaz Luchador 
 *
 */
public interface Luchador {
    void atacar();
    void recibirGolpe(int danio);
}