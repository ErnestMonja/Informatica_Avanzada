public class Sala {
    private String nombre;
    private int capacidad;
    private Ubicacion ubicacion;

    public Sala(String nombre, int capacidad, Ubicacion ubicacion) {
        //TODO Implementar método
    }

    public String getNombre() {
        //TODO Implementar
    }
    public int getCapacidad() { 
        //TODO Implementar
    }
    public Ubicacion getUbicacion() { 
        //TODO Implementar
    }
    
    /**
     * Setea la capacidad de la sala
     * solo si la capacidad es mayor a 0
     */
     
    public void setCapacidad(int capacidad) { 
        //TODO Implementar
    }
    public void setUbicacion(Ubicacion ubicacion) { 
        //TODO Implementar
    }
    
    @Override
    /**
     * Retorna una representación de la Sala como String con el formato
     * 
     * "Sala <nombre> (capacidad: <capacidad>, ubicacion: <ubicacion>)"
     * 
     *  Ejemplo: 
     *      Sala Uritorco (capacidad: 6, ubicacion: Norte)
     */
    public String toString() { 
        //TODO Implementar
    }
}