public interface Cancelable {
    void cancelar();
}