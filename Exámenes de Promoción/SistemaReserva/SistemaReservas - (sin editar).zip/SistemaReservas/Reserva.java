import java.time.LocalDateTime;

public class Reserva {
    protected Sala sala;
    protected Usuario usuario;
    protected LocalDateTime inicio;
    protected int duracionHoras;

    public Reserva(Sala sala, Usuario usuario, LocalDateTime inicio, int duracionHoras) {
        this.sala = sala;
        this.usuario = usuario;
        this.inicio = inicio;
        this.duracionHoras = duracionHoras;
    }

    public Sala getSala() { return sala; }
    public Usuario getUsuario() { return usuario; }
    public LocalDateTime getInicio() { return inicio; }
    public int getDuracionHoras() { return duracionHoras; }

    /**
     * indica si el horario de esta Reserva se superpone con otro horario y duración
     * pasada como parámetro
     * 
     * Por ejemplo, si esta reserva es de 9 a 11,
     *  otroInicio 10, otrasHoras 1 -> true
     *  otroInicio 8, otrasHoras 2 -> True
     *  otroInicio 8, otrasHoras 1 -> false
     * 
     */
    public boolean seSuperpone(LocalDateTime otroInicio, int otrasHoras) {
       //TODO Implementar
    }

    @Override
    /**
     * Retorna un string que represente la Reserva con el formato
     * "Reserva de <nombre_sala> por <usuario> desde <hora_inicio> por <duracion> horas""     * 
     * Ej
     *  "Reserva de Uritorco por ]Juan Perez <jp@perez.com> desde 17:00 por 1 horas"
     */
    public String toString() {
        //TODO Implementar
        return "";
    }
}