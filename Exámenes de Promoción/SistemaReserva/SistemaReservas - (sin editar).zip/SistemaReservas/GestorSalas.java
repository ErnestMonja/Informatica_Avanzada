import java.util.*;

public class GestorSalas {
    private List<Sala> salas = new ArrayList<>();

    /**
     * Agrega una Sala a la lista de salas del gestor
     */
    public void agregarSala(Sala sala) {
        //TODO Implementar
    }

    /**
     * Elimina de la lista la Sala cuyo nombre coincide
     * con el nombre pasado como argumento.
     */
    public void eliminarSala(String nombre) {
        //TODO Implementar
    }

    /**
     * Actualiza la capacidad y ubicación de la Sala cuyo
     * nombre coincide con el nombre pasado como argumento.
     */
    public void modificarSala(String nombre, int nuevaCapacidad, Ubicacion nuevaUbicacion){
        //TODO Implementar
    }

    /**
     * Devuelve la Sala cuyo nombre coincide con el nombre
     * pasado como argumento
     */
    public Sala buscarSala(String nombre) {
        //TODO Implementar
        return null;
    }

    /**
     * Devuelve una lista con todas las Salas del
     * gestor de Salas
     */
    public List<Sala> getTodas() {
        //TODO Implementar
    }
}