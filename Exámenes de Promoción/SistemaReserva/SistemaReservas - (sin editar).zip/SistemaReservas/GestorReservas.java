import java.util.*;
import java.time.LocalDateTime;

public class GestorReservas {
    private GestorSalas gestorSalas;
    protected Map<Sala, List<Reserva>> reservas;

    public GestorReservas(GestorSalas gestorSalas) {
        this.gestorSalas = gestorSalas;
        reservas = new HashMap<>();
    }
    
    public List<Reserva> getReservasPorSala (String nombreSala){
        Sala sala = gestorSalas.buscarSala(nombreSala);
        List<Reserva> listaReservas;
        if (sala !=null && reservas.containsKey(sala)) {
           listaReservas = reservas.get(sala);
        }
        return listaReservas;
    }

    /**
     * Reserva una sala para un usuario, a la hora y con la duración indicada
     *  
     * Si la sala no existe en el gestor de Salas -> Lanza Exception ()
     * Revisa todas las reservas asociadas a la sala, y si existe alguna
     * que se superpone -> Lanza Exception )=
     * 
     * Si la sala existe, y no tienen ninguna reserva superpuesta
     * se genera una nueva Reserva y se agrega al mapa de reservas
     * y retorna true
     * 
     * @throw Exception si la sala no existe, o si tiene una reserva en el 
     * horario requerido
     * @return true si se pudo generar la reserva.
     * 
     */
    public boolean reservar(String nombreSala, Usuario usuario, LocalDateTime inicio, int duracion) throws Exception {
        //TODO implementar método.
        return true;
    }

    /**
     * Libera la sala de la reserva agendada a la hora epecificada.
     * 
     * Obitene la Sala por su nombre del gestor de Salas, si no existe o no tiene
     * reservas asociadas, no hace nada.
     * 
     * Recorre la lista de reservas de la sala, busca si hay alguna que inicie
     * a la hora especificada y la remueve.
     * 
     */
    public void liberar(String nombreSala, LocalDateTime inicio) {
        //TODO implementar. 
    }

    /**
     * devuevle una lista de todas las salas DISPONIBLES con una capacidad
     * mínima y en una ubicación.
     * 
     * Recorre todas las salas existentes, y de cada sala recorre la lista de 
     * reservas y determina si  están o no disponibles a la hora indicada 
     * por el tiempo indicado. Si está disponible, agrega la Sala a la lista.
     * 
     * @return la lista con todas las salas disponbiles.
     */
    public List<Sala> disponibles(LocalDateTime inicio, int duracion) {
        List<Sala> disponibles = new ArrayList<Sala>();
        List<Sala> todas = gestorSalas.getTodas();
        //TODO implementar método
        return null;
     
    }
}