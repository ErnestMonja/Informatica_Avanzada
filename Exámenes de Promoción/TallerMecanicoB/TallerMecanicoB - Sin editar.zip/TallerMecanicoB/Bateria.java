/**
 * Representa una batería que puede cargarse y descargarse.
 * La unidad de carga depende del modelo, pudiendo ser cualquier
 * porcentaje como ser 1%, 2%, ..., 10%, etc.
 */
class Bateria extends Combustible {
    /**
     * Un constructor para una batería con 70% carga inicial
     * y unidad de carga de 5%.
     * 
     * @param id El código del producto
     * @param descripcion Detalle de la batería
     * @param unidadCarga Un valor en porcentaje
     * @param costoUnidadCarga Precio del costo de recarga por unindad
    */
    // TODO Implementar el constructor
    
    /**
     * Un constructor para una batería con 50% carga inicial.
     * 
     * @param id El código del producto
     * @param descripcion Detalle de la batería
     * @param unidadCarga Un valor en porcentaje
     * @param costoUnidadCarga Precio del costo de recarga por unindad
    */
    // TODO Implementar el constructor
    

    // TODO Implementer los métodos faltantes de la inteface Recargable


    @Override
    public String toString() {
        return "Bateria []";
    }

}