public class DineroInsuficienteException extends Exception {

    private static final long serialVersionUID = 10L;
    
}
