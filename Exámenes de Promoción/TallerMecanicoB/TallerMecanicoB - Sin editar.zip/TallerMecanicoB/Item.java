abstract class Item {
    private static Integer contador = 0;
    private final String id;
    private String descripcion;
    private Double precio;

    /**
     * Constructor simple que genera el id y setea la descripcion
     * en el texto "Sin descripcion"
     * @param id El id del item
     */
    public Item (final String id) {
        // TODO - Implementar constructor
    }
    
    /**
     * Constructor que genera el id y setea la descripcion
     * @param id El id del item
     * @param descripcion La descripción del elemento
     */
    public Item (final String id, String descripcion) {
        // TODO - Implementar constructor
    }
    
    /**
     * Constructor que genera el id y setea la descripcion y el precio
     * @param id El id del item
     * @param descripcion La descripción del elemento
     * @param precio El precio del producto
     */
    public Item (final String id, String descripcion, Double precio) {
        // TODO - Implementar constructor
    }

    /**
     * Genera el ID del producto uniendo el ID provisto con el valor
     * del contador de elementos separados por un guion bajo "_".
     * Ejemplo:
     *   Agrego una Bateria  --> ID es "BAT_1"
     *   Agrego otra Bateria --> ID es "BAT_2"
     *   Agrego un Tanque    --> ID es "TAN_3"
     * El contador siempre se incrementa.
     * @param id El ID a generar
     * @return
     */
    private String generarId (final String id) {
        // TODO - Implementar metodo
        return null;
    }

    /**
     * El precio de lista del producto con descuento
     *  -  5% de descuento es 0.05
     *  - 25% de descuento es 0.25
     * @param porcentaje El descuento a realizar
     * @return El precio de lista
     */
    public Double getPrecioConDescuento(final Double porcentaje) {
        // TODO - Implementar metodo
        return null;
    }

    /**
     * El precio de lista del producto
     * @return El precio de lista
     */
    public Double getPrecio() {
        return precio;
    }

    public String getId() {
        return id;
    }    
    
    public String getDescripcion() {
        return descripcion;
    }    

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }    
    
    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Item [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + "]";
    }  
}