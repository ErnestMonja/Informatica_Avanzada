/**
 * La clase Taller modela las gestiones de compra y venta de
 * autopartes.
 * 
 * Se comienza con dinero en la billetera y se debe comprar
 * y vender autoparted.
 */
public class Taller {
    private Billetera billetera;
    private RegistroAutopartes catalogo;

    /**
     * Crea el objeto Taller, desde el cual se gestiona
     * al resto de los objetos.
     * Debe instanciarse el RegistroAutopartes y la billetera
     * con $100.
     * Inicialmente no hay ninguna autoparte.
     */
    public Taller () {
        // TODO implementar metodo
    }


    public void comprarAutoparte(Item item) {
        comprarAutoparte(item, 1);
    }
    
    /**
     * Se utiliza para comprar una autoparte y agregarla al catalogo.
     * 
     * La operacion se concreta si hay dinero suficiente en la billetera.
     * 
     * Notar que la billetera puede lanzar DineroInsuficienteException.
     * Si no hay dinero suficiente, se imprime el mensaje "Compra fallida".
     *  
     * @param autoparte La autoparte a comprar.
     * @param cantidad La cantidad a comprar.
     */
    public void comprarAutoparte(Item autoparte, Integer cantidad) {
        // TODO implementar metodo
    }


    public void venderAutoparte(Item item) {
        venderAutoparte(item, 1);
    }
    
    /**
     * Se utiliza para vender una autoparte del catalogo. El precio de
     * venta en de un 25% más sobre el precio del item.
     * 
     * La operacion se concreta si la autoparte existe en el catálogo.
     * 
     * Se debe actualizar el dinero en la billetera.
     * 
     * Notar que la autoparte puede no existir, en ese caso se debe lanzar
     * IllegalArgumentException e imprimir el mensaje "Venta fallida".
     *  
     * @param autoparte La autoparte a vender.
     * @param cantidad La cantidad a vender.
     */
    public void venderAutoparte(Item autoparte, Integer cantidad) {
        // TODO implementar metodo
    }

    /**
     * Se utiliza para recargar una autoparte que lo permita al máximo.
     * 
     * La operacion se concreta si hay dinero suficiente en la billetera.
     * 
     * Notar que la billetera puede lanzar DineroInsuficienteException.
     * Si no hay dinero suficiente, se imprime el mensaje "Carga fallida".
     *  
     * @param autoparte La autoparte a comprar.
     */
    public void cargarCombustible (Recargable item) {
        // TODO implementar metodo
    }
    
    public void vaciarCombustible (Recargable item) {
        item.setPorcentajeCarga(0);
    }

    public Billetera getBilletera() {
        return billetera;
    }

    public RegistroAutopartes getRegistroAutopartes() {
        return catalogo;
    }
}
