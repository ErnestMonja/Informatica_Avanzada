En este zip hay 2 proyectos:
 - TallerMecanicoB: Este es el proyecto oficial que uno obtiene al descargar 
   el proyecto del lev, el cual tiene ciertas inconsistencias en la redaccion,
   principalmente en:
	- La clase Bateria: La documentación de clase del proyecto difiere de 
	  la que el lev presenta y la que vale es la del lev.
	- La clase RegistroAutopartes: Se pide implementar esta clase, pero de
	  no tener el lev, es imposible saber que métodos se piden implementar.
 - TallerMecanicoB-corregido: Este proyecto soluciona los dos problemas que
   mencionados anteriormente y esta listo para ser programado segun el javadoc
   correcto.

Recomiendo usar la version corregida ya que no cuenta con los defectos mencionados.
