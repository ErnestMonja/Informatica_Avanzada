import java.util.List;

public class RegistroAutopartes {
    private static RegistroAutopartes singleton = null;
    // La key es el ID del Item
    private Map<String, Item> catalogo;

    //Constructor Privado
    private RegistroAutopartes() {
        this.catalogo = new HashMap<>();
    }

    public Map<String, Item> getCatalogo(){
        return catalogo;
    }


    /**
     * Este metodo asegura que siempre se devuelva el mismo objeto registro desde
     * cualquier lado que se llame. Ej:
     * 
     * RegistroAutopartes miRegistro = RegsitroAutopartes.getRegistro();
     * 
     * @return El registro existente.
     */
    public static RegistroAutopartes getRegistro() {
        if (singleton == null) {
            singleton =  new RegistroAutopartes();
        }
        return singleton;
    }

    /**
     * Limpia el registro, dejandolo vacio 
     */
    public void limpiarRegistro() {
        this.catalogo.clear();
    }
    
    /**
     * Agrega una autoparte al registro. 
     * 
     * @param parte La autoparte a agregar.
     * @throws IllegalArgumentException Si la autoparte es null.
    */
    public void agregarAutoParte(Item parte) {
        // TODO implementar metodo
    }

    /**
     * Remueve una autoparte del registro.
     * 
     * @param id El ID de la autoparte a quitar del registro.
     * @throws IllegalArgumentException Si el ID es null o cadena vacía.
     */
    public void removerAutoParte(String id) {
        // TODO implementar metodo
    }

    /**
     * Verifica si una autoparte existe en el registro.
     * 
     * @param id El ID de la autoparte a buscar.
     * @throws IllegalArgumentException Si el ID es null o cadena vacía.
     */
    public Boolean contains(String id) {
        // TODO implementar metodo
        return null;
    }

    // Los metodos de listas son para hacer distintas preguntas
    /**
     * Genera una lista de las autopartes registradas
     * por orden alfabético de la descripción.
     * 
     * El formato de cada fila es el siguiente:
     * "<ID> | <descripcion> | <precio>"
     * 
     * por ej. : "bat60a12v | Bateria auto | $56000.0"
     * (considerar espacios en blanco)
     * 
     * @return Una lista ordenada por descripción
     */
    public List<String> getListadoPorDescripcion()
    {
        // TODO implementar metodo
        return null;
    }

    public Integer cantidadRegistros () {
        return catalogo.size();
    }

    @Override
    public String toString() {
        return "RegistroAutopartes [size=" + cantidadRegistros() + ", catalogo=" + catalogo + "]";
    }    
}