public abstract class Liquido extends Elemento {
    
}
