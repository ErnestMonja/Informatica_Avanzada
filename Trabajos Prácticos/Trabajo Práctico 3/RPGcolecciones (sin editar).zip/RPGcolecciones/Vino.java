public class Vino extends Liquido {

    public Vino () {
        setNombre("Vino");
        setPeso(20);
    }

}
