public abstract class Recipiente extends Elemento implements Contenedor {
    
}
