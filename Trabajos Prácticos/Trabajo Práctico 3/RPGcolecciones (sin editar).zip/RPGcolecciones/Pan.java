public class Pan extends Elemento implements Portable {

    public Pan() {
        setNombre("Pan");
        setPeso(2);
    }
    
}
