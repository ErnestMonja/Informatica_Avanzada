public class Pluma extends Elemento implements Portable {

    public Pluma() {
        setNombre("Pluma");
        setPeso(1);
    }
    
}